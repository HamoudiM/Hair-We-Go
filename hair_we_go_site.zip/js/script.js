
document.addEventListener("DOMContentLoaded", () => {
    console.log("HAIR WE GO website loaded.");
});
